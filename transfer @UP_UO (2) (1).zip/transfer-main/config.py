import os


class Config(object):
    TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "6735766047:AAFxEPzcDsSgA8Nqjn2V8ecS6AJxMCtPap0")

    APP_ID = int(os.environ.get("APP_ID", 21840855))

    API_HASH = os.environ.get("API_HASH", "7778be8d8708969befadcca8a7e7d45c")
